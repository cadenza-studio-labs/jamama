export function readPairingCode() {
  if (location.origin !== 'http://127.0.0.1:4177' || !document.getElementById('companion-dialog')?.open) return null;
  const code = document.getElementById('companion-code')?.textContent?.trim();
  return /^[A-F0-9]{10}$/.test(code || '') ? code : null;
}

export async function jamamaRequest(input) {
  if (location.origin !== 'http://127.0.0.1:4177') throw new Error('Use the Jamama tab on this computer.');
  async function api(path, method = 'GET', body, token, csrf) {
    const response = await fetch(path, { method, credentials: 'same-origin', headers: {
      'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(csrf ? { 'X-CSRF-Token': csrf } : {}),
    }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Jamama could not finish that request.');
    return data;
  }
  const room = () => {
    if (!/^[A-Z2-9]{6}$/.test(input.code || '')) throw new Error('Choose a valid Jam.');
    return `/api/rooms/${input.code}`;
  };
  if (input.action === 'rooms') return api('/api/nearby');
  if (input.action === 'join') return api(room() + '/join', 'POST', { name: input.name, provider: 'ytmusic' });
  if (input.action === 'disconnect') {
    const connection = await api('/api/connections');
    return api('/api/connections/ytmusic/disconnect', 'POST', {}, undefined, connection.csrfToken);
  }
  if (input.action === 'stop-feed') { globalThis.jamamaMusicCompanionFeed?.close(); delete globalThis.jamamaMusicCompanionFeed; return { stopped: true }; }
  if (!/^[a-f0-9]{48}$/.test(input.token || '')) throw new Error('Join a Jam first.');
  if (input.action === 'subscribe') {
    globalThis.jamamaMusicCompanionFeed?.close();
    const feed = new WebSocket(`ws://127.0.0.1:4177${room()}/socket`);
    globalThis.jamamaMusicCompanionFeed = feed;
    feed.onopen = () => feed.send(JSON.stringify({ type: 'authenticate', token: input.token }));
    const send = (event, data) => chrome.runtime.sendMessage({ type: 'jamama-room-event', code: input.code, event, data }).catch(() => feed.close());
    feed.onmessage = (message) => { try { const packet = JSON.parse(message.data); if (packet.event === 'room') void send('room', packet.data); if (packet.event === 'ended') { feed.close(); void send('ended', null); } } catch {} };
    return { subscribed: true };
  }
  if (input.action === 'room') return api(room(), 'GET', undefined, input.token);
  if (input.action === 'leave') return api(room() + '/leave', 'POST', {}, input.token);
  if (input.action !== 'queue' || !/^[A-Za-z0-9_-]{1,200}$/.test(input.playlistId || '') || !/^[A-Za-z0-9_-]{11}$/.test(input.videoId || '') || !Number.isSafeInteger(input.offset) || input.offset < 0 || input.offset > 100000) throw new Error('Choose a captured playlist song.');
  const tracks = await api(`/api/library/ytmusic/playlists/${encodeURIComponent(input.playlistId)}/tracks?offset=${input.offset}`);
  const track = tracks.items?.find((item) => item.id === `ytmusic:${input.videoId}`);
  if (!track) throw new Error('Sync the open playlist before requesting this song.');
  return api(room() + '/queue', 'POST', { provider: 'ytmusic', trackId: track.id, requestId: input.requestId }, input.token);
}
