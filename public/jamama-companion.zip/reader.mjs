export function readMusicPlaylist() {
  const source = new URL(location.href);
  if (source.origin !== 'https://music.youtube.com' || source.pathname !== '/playlist' || !source.searchParams.get('list')) throw new Error('Open a playlist on music.youtube.com first.');
  const header = document.querySelector('ytmusic-responsive-header-renderer, ytmusic-detail-header-renderer');
  const name = header?.querySelector('h1, .title')?.textContent?.trim();
  if (!name) throw new Error('The playlist is still loading. Wait for its title and songs to appear.');
  const countMatch = header.innerText.match(/([\d,]+)\s+(?:tracks?|songs?)\b/i);
  const expectedCount = countMatch ? Number(countMatch[1].replaceAll(',', '')) : null;
  const tracks = [];
  for (const row of document.querySelectorAll('ytmusic-playlist-shelf-renderer ytmusic-responsive-list-item-renderer')) {
    const titleLink = [...row.querySelectorAll('a[href]')].find((link) => {
      try { const url = new URL(link.getAttribute('href'), source); return url.origin === source.origin && url.pathname === '/watch' && /^[A-Za-z0-9_-]{11}$/.test(url.searchParams.get('v') || ''); } catch { return false; }
    });
    if (!titleLink?.textContent?.trim()) continue;
    const links = [...row.querySelectorAll('a[href]')];
    const artists = links.filter((link) => /(?:^|\/)channel\//.test(link.getAttribute('href'))).map((link) => link.textContent.trim()).filter(Boolean);
    const album = links.find((link) => /(?:^|\/)browse\/MPRE/.test(link.getAttribute('href')))?.textContent.trim() || '';
    const time = [...row.querySelectorAll('yt-formatted-string.fixed-column')].map((node) => node.textContent.trim()).find((value) => /^(?:\d+:)?\d{1,2}:\d{2}$/.test(value));
    const durationMs = time ? time.split(':').reduce((sum, part) => sum * 60 + Number(part), 0) * 1000 : null;
    tracks.push({ videoId: new URL(titleLink.getAttribute('href'), source).searchParams.get('v'), title: titleLink.textContent.trim(), artist: artists.join(', '), album,
      artistIsUploader: !album, durationMs, artworkUrl: row.querySelector('img')?.getAttribute('src') || null });
  }
  if (!tracks.length) throw new Error('No playlist songs are loaded yet. Open the song list and try again.');
  return { sourceUrl: source.href, name, artworkUrl: header.querySelector('img')?.getAttribute('src') || null, expectedCount, tracks };
}
