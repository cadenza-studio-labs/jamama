import { readMusicPlaylist } from './reader.mjs';
import { jamamaRequest, readPairingCode } from './jamama-bridge.mjs';

const $ = (id) => document.getElementById(id);
const base = 'http://127.0.0.1:4177';
let pairing, membership, room, capture, captureId, lastCapture = '', busy = false, reading = false;
const attempts = new Map();
function status(message, tone = '') { $('status').textContent = message; $('status').className = tone; }
function render() {
  $('pairing').hidden = Boolean(pairing); $('connected').hidden = !pairing;
  $('join-section').hidden = Boolean(membership); $('jam-section').hidden = !membership;
  for (const button of document.querySelectorAll('button')) button.disabled = busy || (button.dataset.request !== undefined && !membership);
}
function text(tag, value, className = '') { const node = document.createElement(tag); node.textContent = value; node.className = className; return node; }
async function findJamama() {
  const tabs = await chrome.tabs.query({ url: base + '/*' });
  const tab = tabs.find((item) => item.id === pairing?.appTabId) || tabs[0];
  if (!tab) throw new Error('Keep Jamama open in this Chrome profile, then try again.');
  if (pairing && pairing.appTabId !== tab.id) { pairing.appTabId = tab.id; await chrome.storage.session.set({ jamamaPairing: pairing }); }
  return tab;
}
async function bridge(input) {
  const tab = await findJamama();
  const results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: jamamaRequest, args: [input] });
  if (!results[0]?.result) throw new Error('Jamama did not return a result. Keep its tab open and try again.');
  return results[0].result;
}
async function request(path, input, authorized = false) {
  let response;
  try { response = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Jamama-Extension': chrome.runtime.id, ...(authorized ? { Authorization: `Bearer ${pairing.token}` } : {}) }, body: JSON.stringify(input) }); }
  catch { throw new Error('Open Jamama on this computer first, then try again.'); }
  let data;
  try { data = await response.json(); } catch { throw new Error('Jamama returned an unreadable response. Try again.'); }
  if (!response.ok) {
    if (data.code === 'pairing_expired' && authorized) {
      await bridge({ action: 'stop-feed' }).catch(() => {});
      pairing = null; membership = null;
      await chrome.storage.session.remove(['jamamaPairing', 'jamamaRoom']);
    }
    throw new Error(data.error || 'Could not connect to Jamama.');
  }
  return data;
}
async function run(operation) {
  if (busy) return;
  busy = true; render(); status('Working…');
  try { await operation(); }
  catch (error) { status(error.message || 'Try again.', 'error'); }
  finally { busy = false; render(); }
}
function renderRoom(snapshot) {
  room = snapshot;
  $('jam-title').textContent = room.title || 'Shared queue';
  $('jam-meta').textContent = `${room.members.length} people · ${room.queue.length} requests`;
  const playing = room.playback?.currentTrack || room.nowPlaying?.hostTrack;
  $('now-playing').textContent = playing ? `Host: ${playing.title} · ${playing.artist}` : 'Playback belongs to the host.';
  $('queue-empty').hidden = room.queue.length > 0;
  $('queue').replaceChildren(...room.queue.map((entry) => {
    const node = text('li', entry.track?.title || 'Song unavailable');
    node.append(text('small', `${entry.track?.artist || 'Unknown artist'} · ${entry.name}`));
    return node;
  }));
  render();
}
async function refreshRooms() {
  const data = await bridge({ action: 'rooms' });
  $('nearby-rooms').replaceChildren(...data.rooms.map((item) => {
    const button = text('button', item.hostName, 'jam-option');
    button.append(text('small', `${item.title} · ${item.memberCount} people`));
    button.onclick = () => run(() => join(item.code));
    return button;
  }));
  if (!data.rooms.length) $('nearby-rooms').append(text('p', 'No online hosts found. Start a Jam in Jamama, or use a Jam code.', 'muted'));
}
async function subscribe() { if (membership) await bridge({ ...membership, action: 'subscribe' }); }
async function join(code) {
  const name = $('guest-name').value.trim();
  if (!name) { $('guest-name').focus(); throw new Error('Enter your name before joining.'); }
  const result = await bridge({ action: 'join', name, code: code.trim().toUpperCase() });
  membership = { code: result.room.code, token: result.token, memberId: result.memberId };
  await chrome.storage.session.set({ jamamaRoom: membership, jamamaGuestName: name });
  renderRoom(result.room); await subscribe(); status('Joined. Choose a playlist song below.', 'success');
}
async function pair(code, tab) {
  if (!/^[A-F0-9]{10}$/.test(code)) throw new Error('Use the 10-character pairing code from Jamama.');
  pairing = { ...await request('/api/companion/claim', { code }), appTabId: tab.id };
  membership = null; await chrome.storage.session.remove('jamamaRoom');
  await chrome.storage.session.set({ jamamaPairing: pairing }); $('pair-code').value = '';
  render(); await refreshRooms(); status('Connected. Browse YouTube Music and open a playlist.', 'success');
}
function renderCapture() {
  $('playlist-name').textContent = capture.name;
  const count = capture.tracks.length;
  $('capture-note').textContent = capture.expectedCount === count
    ? `${count} song entries synced.`
    : `${count}${capture.expectedCount ? ` of ${capture.expectedCount}` : ''} entries synced. Unloaded, unavailable, or non-song entries can be missing.`;
  $('playlist-tracks').replaceChildren(...capture.tracks.map((track, index) => {
    const row = document.createElement('div'); row.className = 'track';
    let image;
    try {
      const url = new URL(track.artworkUrl);
      if (url.protocol === 'https:' && !url.username && !url.password && ['googleusercontent.com', 'ytimg.com', 'ggpht.com'].some((host) => url.hostname === host || url.hostname.endsWith(`.${host}`))) { image = document.createElement('img'); image.src = url.href; image.alt = ''; image.loading = 'lazy'; image.referrerPolicy = 'no-referrer'; }
    } catch {}
    row.append(image || text('div', '', 'cover'));
    const info = document.createElement('div'); info.append(text('strong', track.title), text('small', track.artist || 'Unknown artist')); row.append(info);
    const button = text('button', '+'); button.dataset.request = track.videoId; button.setAttribute('aria-label', `Add ${track.title} to shared queue`);
    const playlistId = captureId;
    button.onclick = () => run(async () => {
      if (!membership) throw new Error('Join a Jam before requesting songs.');
      const key = `${playlistId}:${track.videoId}`;
      if (!attempts.has(key)) attempts.set(key, crypto.randomUUID());
      const result = await bridge({ ...membership, action: 'queue', playlistId, videoId: track.videoId, offset: Math.floor(index / 100) * 100, requestId: attempts.get(key) });
      attempts.delete(key); renderRoom(result.room); status(`${track.title} added to the shared queue.`, 'success');
    });
    row.append(button); return row;
  }));
  render();
}
async function syncPlaylist(automatic = false) {
  if (reading || !pairing) return;
  reading = true;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url?.startsWith('https://music.youtube.com/playlist?')) {
      if (automatic) return;
      throw new Error('Open a playlist on YouTube Music, then click Jamama’s toolbar icon to give this sidebar access.');
    }
    const result = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: readMusicPlaylist });
    const playlist = result[0]?.result;
    if (!playlist) throw new Error('Let the playlist song list finish loading.');
    const serialized = JSON.stringify(playlist);
    if (automatic && serialized === lastCapture) return;
    const data = await request('/api/companion/library', playlist, true);
    capture = playlist; captureId = data.playlist.id; lastCapture = serialized;
    renderCapture(); if (!automatic) status('Playlist information synced. Your original playlist is unchanged.', 'success');
  } finally { reading = false; }
}
$('pair-from-tab').onclick = () => run(async () => {
  const tabs = await chrome.tabs.query({ url: base + '/*' }); const candidates = [];
  for (const tab of tabs) {
    const results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: readPairingCode });
    if (results[0]?.result) candidates.push({ tab, code: results[0].result });
  }
  if (candidates.length !== 1) throw new Error(candidates.length ? 'Keep only one Jamama companion pairing dialog open.' : 'In Jamama, open Music accounts → YouTube Music → Connect companion first.');
  await pair(candidates[0].code, candidates[0].tab);
});
$('pair-button').onclick = () => run(async () => pair($('pair-code').value.trim().toUpperCase(), await findJamama()));
$('sync-button').onclick = () => run(() => syncPlaylist());
$('refresh-rooms').onclick = () => run(refreshRooms);
$('join-code').onclick = () => run(() => join($('jam-code').value));
$('open-music').onclick = () => chrome.tabs.create({ url: 'https://music.youtube.com/library' });
$('leave-jam').onclick = () => run(async () => {
  await bridge({ ...membership, action: 'leave' }); await bridge({ action: 'stop-feed' });
  membership = null; room = null; await chrome.storage.session.remove('jamamaRoom'); render(); await refreshRooms(); status('You left the Jam.');
});
$('disconnect').onclick = () => run(async () => {
  if (membership) await bridge({ ...membership, action: 'leave' }).catch(() => {});
  await bridge({ action: 'stop-feed' }).catch(() => {});
  await bridge({ action: 'disconnect' });
  pairing = null; membership = null; capture = null; $('auto-sync').checked = false;
  await chrome.storage.session.remove(['jamamaPairing', 'jamamaRoom']);
  status('YouTube Music companion disconnected from Jamama.');
});
chrome.runtime.onMessage.addListener((message, sender) => {
  if (sender.id !== chrome.runtime.id || sender.tab?.id !== pairing?.appTabId || message.type !== 'jamama-room-event' || message.code !== membership?.code) return;
  if (message.event === 'room') renderRoom(message.data);
  if (message.event === 'ended') { membership = null; room = null; void chrome.storage.session.remove('jamamaRoom'); render(); status('The host ended this Jam.'); }
});
window.addEventListener('pagehide', () => { void bridge({ action: 'stop-feed' }).catch(() => {}); });
setInterval(() => {
  if (!pairing || busy || document.visibilityState !== 'visible') return;
  if ($('auto-sync').checked) void syncPlaylist(true).catch((error) => { status(error.message, 'error'); render(); });
}, 10000);
const saved = await chrome.storage.session.get(['jamamaPairing', 'jamamaRoom', 'jamamaGuestName']);
pairing = saved.jamamaPairing?.expiresAt > Date.now() ? saved.jamamaPairing : null;
membership = pairing ? saved.jamamaRoom : null;
$('guest-name').value = saved.jamamaGuestName || '';
render();
if (pairing) {
  try {
    if (membership) { renderRoom(await bridge({ ...membership, action: 'room' })); await subscribe(); }
    else await refreshRooms();
  } catch (error) { membership = null; await chrome.storage.session.remove('jamamaRoom'); render(); status(error.message, 'error'); }
}
